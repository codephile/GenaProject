package InterlacedOracle;


public abstract class InfixArith {

	abstract public int main(String inputStr) throws Exception;

}
