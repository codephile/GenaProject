package TestGenerationWithOracleV1;

import java.util.Formatter;
//import java.util.Scanner;
import java.io.*;
import InterlacedOracle.*;

public class TestGeneration {
	
	public static void main( String[] args ) {
		
		Formatter output, outputExpr;
		// Added by SMR as part of change request 1 on 09/14/2014
		Formatter outputTC;
		InfixArithFaultDetector socketSUT = new InfixArithFaultDetector();
		
		SymbolicGrammar g = new SymbolicGrammar();
		
//		g.createGrammarFromFile("fdTestAddCFGwithSem.txt");
		g.createGrammarFromFile("testSEM.txt");
		System.out.println("Grammar Map:");
		g.printGrammarMap();
		System.out.println("End of Grammar Map");
		
		CoverageTree t = new CoverageTree(g);
		
		t.newCoverageTree();
		
		
//		output = t.setOutputFile("test1WithSem.txt");
		output = t.setOutputFile("casesWithSem.txt");
		
		// Added by SMR as part of change request 1 on 09/14/2014
		outputTC = t.setTraversalChainFile("traversalChainperTestCase.txt");
		
		try {
			outputExpr = new Formatter("testcases.txt");
		
			for (int i = 0; i < 100; i++) {
				output.format("%d: ", i);
				
				// Added by SMR as part of change request 1 on 09/14/2014
				t.resetTraversalChain();
				
				String test = t.newTestCase();
				if (test == null) break;
				
				// Added by SMR as part of change request 1 on 09/14/2014
				String reqString = t.getAllFeatures();
				String resultString = "Expected Result: "+t.evaluate();
				String logFileName = "TestCaseNo"+i+"Result.txt";
				socketSUT.feedSUTSingleTestCase(reqString, test, resultString, logFileName);
				
				output.format("\n");
				
		//t.printParseTree();
				output.format("[[ %s ]]\n", test);
				output.format("Expected Result: %s\n\n", t.evaluate());
				
				// Added by SMR as part of change request 1 on 09/14/2014
				t.dumpTraversalChain(i);
				
				outputExpr.format("%s\n", test);
			}
			t.closeOutputFile();
			
			// Added by SMR as part of change request 1 on 09/14/2014
			t.closeTraversalChainFile();
			
			outputExpr.close();
		}
		catch ( FileNotFoundException e1 ) {
			System.err.println( "Exception: File cannot be created!");
			System.exit(1);
		}
		
/*		Scanner input; 
		
		try {
			input = new Scanner( new File( "TR_1000ExpWithReq.txt" ) );
			output = new Formatter( "TR_1000ExpWithReqPlus.txt" );

			int j = 1;
			while (input.hasNextLine()) {
				String rLine = input.nextLine();
//				String pLine = input.nextLine();
				String eLine = input.nextLine();
				input.nextLine();
				
				rLine = rLine.replaceFirst("\\d+:", "").trim();
//				pLine = pLine.replaceFirst("\\[", "").replaceFirst("\\]","").trim();
//				eLine = eLine.replaceFirst("\\[\\[", "").replaceFirst("\\]\\]","").trim();
				
				rLine = g.reqProcess(rLine);
				
				output.format("%d: %s\n", j, rLine);
				output.format("%s\n\n", eLine);
				
				j++;
			}

			input.close();
			output.close();
			
		}
		catch ( Exception e1 ) {
			System.err.printf( "Error Opening file: %s.\n", e1 );
			System.exit(1);
		}
	*/	
		
//		t.exportCoverageTree();
//		t.exportCoverageTreeWithProbability();
	}
	
	
	
	public static void gena( String arg, int size ) {
		
		Formatter output, outputExpr;
		
		SymbolicGrammar g = new SymbolicGrammar();
		
		g.createGrammarFromFile(arg);
//		g.createGrammarFromFile("fdTestAddCFGwithSem.txt");
//		g.createGrammarFromFile("fdTestAddCFG.txt");
//		g.createGrammarFromFile("testSEM1.txt");
//		g.createGrammarFromFile("testWebSemGrammar.txt");
		g.printGrammarMap();
		
		CoverageTree t = new CoverageTree(g);
		
		t.newCoverageTree();
//		output = t.setOutputFile("test1WithSem.txt");
		output = t.setOutputFile("fdTestAddWithSem.txt");
		
		try {
			outputExpr = new Formatter("fdTestAddcases.txt");
		
			for (int i = 0; i < size; i++) {
				output.format("%d: ", i);
				String test = t.newTestCase();
				if (test == null) break;
				
				output.format("\n");
				
//				t.printParseTree();
				output.format("[[ %s ]]\n", test);
				output.format("Expected Result: %s\n\n", t.evaluate());
				
				outputExpr.format("%s\n", test);
			}
			t.closeOutputFile();
			outputExpr.close();
		}
		catch ( FileNotFoundException e1 ) {
			System.err.println( "Exception: File cannot be created!");
			System.exit(1);
		}
		
/*		Scanner input; 
		
		try {
			input = new Scanner( new File( "TR_1000ExpWithReq.txt" ) );
			output = new Formatter( "TR_1000ExpWithReqPlus.txt" );

			int j = 1;
			while (input.hasNextLine()) {
				String rLine = input.nextLine();
//				String pLine = input.nextLine();
				String eLine = input.nextLine();
				input.nextLine();
				
				rLine = rLine.replaceFirst("\\d+:", "").trim();
//				pLine = pLine.replaceFirst("\\[", "").replaceFirst("\\]","").trim();
//				eLine = eLine.replaceFirst("\\[\\[", "").replaceFirst("\\]\\]","").trim();
				
				rLine = g.reqProcess(rLine);
				
				output.format("%d: %s\n", j, rLine);
				output.format("%s\n\n", eLine);
				
				j++;
			}

			input.close();
			output.close();
			
		}
		catch ( Exception e1 ) {
			System.err.printf( "Error Opening file: %s.\n", e1 );
			System.exit(1);
		}
	*/	
		
//		t.exportCoverageTree();
//		t.exportCoverageTreeWithProbability();
	}

}
