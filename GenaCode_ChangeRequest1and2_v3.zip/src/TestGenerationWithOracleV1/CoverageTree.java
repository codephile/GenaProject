package TestGenerationWithOracleV1;

import java.util.Map;
import java.util.Stack;
import java.util.ArrayList;
//import java.util.HashMap;
import java.util.Formatter;
//Added by UNO
import java.util.LinkedList;
import java.util.Iterator;

public class CoverageTree {

	private TreeNode root;
	private SymbolicGrammar sg;
	private Stack<String> stack;
	private Stack<SemNode> semStack;
	private Map< String, ArrayList<Double> > hits;
	private int handler;
	// handler is used to control whether to continue using the existing test generation coverage tree
	// or new a new coverage tree.
	private int testCaseIndex = 0;
	// the index order of a test case, shown in the leaf node of each test case path
	private String outputFileName;
	private Formatter output;
	private String feature;
	private String allFeatures;
	private SemNode sroot;
	// Added by UNO
	private LinkedList<TreeNode> traversalChain = new LinkedList<TreeNode>();
	private LinkedList<String> expressionChain = new LinkedList<String>();
	private LinkedList<String> featureChain = new LinkedList<String>();
	private String traversalChainFile;
	private String expressionChainFile;
	private String featureChainFile;
	private Formatter outputTC, outputEC, outputFC;
	private int featureCounter=1;
//	private String parseTree;
	
	public CoverageTree(SymbolicGrammar s) {
		setSymbolicGrammar(s);
		stack = new Stack<String>();
		semStack = new Stack<SemNode>();
	}
	
	
	
	private void resetSemTree(String s) {
		sroot = new SemNode(s);
	}
	
	
	private SemNode getSemTreeRoot() {
		return sroot;
	}
	
	
	/*
	private void resetParseTree() {
		parseTree = "";
	}
	
	private void appendParseTree(String t) {
		if (parseTree.equals(""))
			parseTree = t;
		else if (parseTree.endsWith("(")) 
			parseTree += t;
		else if (parseTree.endsWith(")")) {
			if (t.startsWith(")"))
				parseTree += t;
			else
				parseTree += "," + t;
		}			
	}

	public void printParseTree() {
//		output.format("[%s] \n", parseTree);
	}
	*/
	
	private boolean isEmptyFeature() {
		return (feature.equals(""));
	}
	
	
	private void resetAllFeatures() {
		allFeatures = "";
	}
	
	
	private void resetFeature() {
		feature = "";
	}
	
	private void appendFeature(String f) {
		feature += f;
	}
	
	private void printFeature() {
//		feature = sg.reqProcess(feature);
		allFeatures += feature + " ";
		
		// Added by UNO
		featureChain.add(allFeatures);
		outputFC.format("\nFeature Index: %d Current Feature: %s, Feature Set: %s", featureCounter, feature, allFeatures);
		featureCounter++;
		
		output.format("%s ", feature);
	}
	
	
	private void printAllFeatures() {
		
		allFeatures = sg.reqProcess(allFeatures);
		output.format("\n%s", allFeatures);
	}
	
	//Added by UNO
	public String getAllFeatures()
	{
		return allFeatures;
	}
	
	
	public String getOutputFile() {
		return outputFileName;
	}
	
	// Added by UNO
	public String getTraversalChainFile() {
		return traversalChainFile;
	}	
	
	// Added by UNO
	public String getExpressionChainFile() {
		return expressionChainFile;
	}	
	
	// Added by UNO
	public String getFeatureChainFile() {
		return featureChainFile;
	}	
	
	public Formatter setOutputFile(String s) {
		outputFileName = s;
		try {
			output = new Formatter(getOutputFile());
		}
		catch ( Exception e) {
			System.err.println( "Unable to open file: " + getOutputFile() + "\n" + e);
			System.exit(0);
		}	
		return output;
	}
	
	// Added by UNO
	public Formatter setTraversalChainFile(String s) {
		traversalChainFile = s;
		try {
			outputTC = new Formatter(getTraversalChainFile());
		}
		catch ( Exception e) {
			System.err.println( "Unable to open file: " + getTraversalChainFile() + "\n" + e);
			System.exit(0);
		}	
		return outputTC;
	}	

	public Formatter setExpressionChainFile(String s) {
		expressionChainFile = s;
		try {
			outputEC = new Formatter(getExpressionChainFile());
		}
		catch ( Exception e) {
			System.err.println( "Unable to open file: " + getExpressionChainFile() + "\n" + e);
			System.exit(0);
		}	
		return outputEC;
	}
	
	public Formatter setFeatureChainFile(String s) {
		featureChainFile = s;
		try {
			outputFC = new Formatter(getFeatureChainFile());
		}
		catch ( Exception e) {
			System.err.println( "Unable to open file: " + getFeatureChainFile() + "\n" + e);
			System.exit(0);
		}	
		return outputFC;
	}	
	
	public void closeOutputFile() {
		if (output != null)
			output.close();
	}
	
	// Added by UNO
	public void closeTraversalChainFile() {
		if (outputTC != null)
			outputTC.close();
	}
	
	// Added by UNO
	public void closeExpressionChainFile() {
		if (outputEC != null)
			outputEC.close();
	}	
	
	// Added by UNO
	public void closeFeatureChainFile() {
		if (outputFC != null)
			outputFC.close();
	}
	
	private int incTestCaseIndex() {
		testCaseIndex++;
		return testCaseIndex;
	}
	
	private void resetTestCaseIndex() {
		testCaseIndex = 0;
	}
	
	
	public void setSymbolicGrammar(SymbolicGrammar s) {
		if (s == null)
			System.err.println("Symbolic Grammar Set Error: no symbolic grammar is given!");
		else
			sg = s;
	}
	
	public SymbolicGrammar getSymbolicGrammar() {
		return sg;
	}
	
	
	private Stack<SemNode> getSemStack() {
		return semStack;
	}
	
/*	private void emptySemStack() {
		getSemStack().removeAllElements();
	}
	
	private boolean isEmptySemStack() {
		return getSemStack().isEmpty();
	}
*/	
	private void pushSemStack(SemNode N) {
		getSemStack().push(N);
	}
	
	private SemNode popSemStack() {
		return getSemStack().pop();
	}	
	
	
	private Stack<String> getStack() {
		return stack;
	}
	
	private void emptyStack() {
		getStack().removeAllElements();
	}
	
	private boolean isEmptyStack() {
//		return getStack().isEmpty();
//		return ( getStack().size() == 2);
		// if all pushed items are with prefix "memo:", then the stack is empty
		int n = getStack().size() - 1;
		boolean emptySoFar = true;
		while (n >= 0 && emptySoFar) {
			emptySoFar = getStack().get(n).startsWith("memo:");
			n--;
		}
		return emptySoFar;
	}
	
	private void pushStack(String s) {
		getStack().push(s);
	}
	
	private String popStack() {
		return getStack().pop();
	}

/*	
	// stack2Str() return an underived string in a sentential form
	private String stack2Str() {
		
		int s = getStack().size();
		String str = "";
		
		for (int i = s-1; i >= 0; i--) {
			if ( !getStack().elementAt(i).startsWith("memo:") )
				str = str + getStack().elementAt(i);
//			str = str + " " + getStack().elementAt(i);
		}
		return str;
	}
*/	
	
/*	private String dumpTerminalPrefixFromStack() {

		int s = getStack().size() - 1;
		String str = "";
		
		while ( s >= 0 ) {
			String token = getStack().elementAt(s);
			if ( token.startsWith("memo:") )
				break;
			if ( getSymbolicGrammar().isVar(token) )
				break;
			popStack();
			str += token;
			s--;
		}		
		return str;
	}
*/	
/*	private String peepStack() {
		return stack.peek();
	}
*/
	
	
	private void newHits() {
//		hits = new HashMap< String, ArrayList<Integer> >();
		sg.resetHitsMap();
		hits = sg.getHitsMap();
//		sg.resetHitsMap();
	}

	public ArrayList<Double> getHits(String key) {		

		return hits.get(key);
		
	}
	


	private double totalHits(ArrayList<Double> hs) {
		
		double t = 0.0;
		double h1 = hs.get(0);
		for (double h : hs) {
			t += h1 / h;
		}
		
		return t;
	}
	
	
	private TreeNode getDerivedNode(TreeNode p, String token) {
		
		TreeNode child = p.getFirstChild();
		ArrayList<Double> tokenHits = sg.getHits(token);
		double total = totalHits(tokenHits);
		int i = 0;
		
		//update the derivation stack
		int previous = stack.lastIndexOf("memo:"+token);
		
		if (previous > 0) {
			// the variable has been met before
			// pi tells which grammar rule was applied when the variable was invoked last time
			int pi = Integer.parseInt( stack.get(previous - 1).substring(5) );
			
			
			// check from stack position: previous + 1  ==> stack.size()
			// to find out the depth of recursion

/*			// linear weight increment
			double w = 1.0;
			// update the hits
			tokenHits.set(pi, w + tokenHits.get(pi));
*/
			
/*			// weight is decreased by the depth of recursion
 * 			double w = 1.0;
 			for (int j = previous + 1; j < stack.size(); j++) {
				if ( stack.get(j).matches("memo:[A-Z].*") )
					w /= 2;
			}
*/			
			// weight increases in an exponential rate
			// update the hits
			tokenHits.set(pi, 2.0 * tokenHits.get(pi));
			
			sg.setHitsMap(token, tokenHits);
			total = totalHits(tokenHits);
		}
		
		if (child != null) { // child nodes already exist
/*			if (child.getHandler() != getHandler()) {			
				// if not current handler, reset nodes
				
				TreeNode q = child;
				i = 0;
				while (q != null) {
					q.nodeReset(getHandler(), (tokenHits.get(0) / tokenHits.get(i)) / total );
					q = q.getNextSibling();
					i++;
				}
			}	
*/
		}
		else { // no children yet

			TreeNode q = null;
			i = 0;
			for (double hit : tokenHits) {
				if (q == null) {
					q = new TreeNode();
					q.nodeReset(getHandler(), ( tokenHits.get(0) / hit )  / total );
					// the probability calculation from Hits distribution:
					// probability = (TotalHits - hit) / (TotalHits * (n - 1))
					// where n is the number of grammar rules
					child = q;
					i++;
				}
				else {
					q.setNextSibling(new TreeNode());
					q = q.getNextSibling();
					q.nodeReset(getHandler(), ( tokenHits.get(0) / hit )  / total );
					i++;
				}
			}
			
			p.setFirstChild(child);
		}
		
		// select a child node in a random way, based on runtime probability distribution
		double r = Math.random();
		double a = 0.0;

		i = 0;
		do {
			a += child.getRunningProbability();
			if (a < r) {
				child = child.getNextSibling();
				if (child == null)
					break;
				else
					i++;
			}
			else {
				break;
			}
		} while (true);
					
		// the following two pushes are critical 
		// for adjusting the distributed probabilities of
		// recursively defined grammar rules
		
		appendFeature( token+"#" );
		appendFeature( String.valueOf(i) );
		appendFeature( "+" );
        // the next line is related to parse tree
		//		appendParseTree(token+i+"(");
		
		GrammarRule grammar = sg.getGrammar(token).get(i);
		String[] tokens = grammar.getStringTokenizer();

		int j = tokens.length;
/*
		while (j > 0) {
			j--;
			stack.push(tokens[j]);
		}
*/		
//		deriveVarSemStack(token, i);   // old version
		
		if ( !stack.isEmpty() && stack.peek() == "semantics" ) {
			
			stack.pop();  // remove the indicator "semantics"
			SemNode sp = semStack.pop();

			stack.push("memo:"+i);
			stack.push("memo:"+token);

			SemanticFun f = getSymbolicGrammar().getSemantics(token).get(i);
			if (f == null) {
				// if the variable (token) has no semantic valuation function defined, 
				// the default one is: (token[0])
				sp.setElement( clearQuotesfromTerminal(tokens[0]) );
				
				while (j > 1) {
					j--;
					stack.push(tokens[j]);
				}

				if ( isVar(tokens[0]) || isSymbolicTerminal(tokens[0]) ) {
					// push semantic node back to the semantic stack
					stack.push("semantics");
					stack.push(tokens[0]);
					semStack.push(sp);
					
				}
				else 
					stack.push(tokens[0]);
			}
			else if (f.isSingletonFun()) {
				// semantic tree simplification
				String varName = f.getSemanticFun().getElement();
				sp.setElement( clearQuotesfromTerminal(varName) );
				
				if ( isVar(varName) || isSymbolicTerminal(varName) ) {
					// push semantic node back to the semantic stack
					while (j > 0) {
						j--;
						if (tokens[j].equals(varName) ) {
							stack.push("semantics");
							stack.push(tokens[j]);
							semStack.push(sp);
						}
						else {
							stack.push(tokens[j]);
						}
					}
				}
				else {
					while (j > 0) {
						j--;
						stack.push(tokens[j]);
					}
				}
			}
			else {
				sp.setFirstChild( f.getCopySemanticFun() );
				
				while (j > 0) {
					j--;
					
					SemNode q = f.find(tokens[j], sp.getFirstChild().getFirstChild());
					if ( q != null ) {
						stack.push("semantics");
						stack.push(tokens[j]);
						semStack.push(q);
					}
					else {
						stack.push(tokens[j]);
					}
				}
				
			}	
		}
		else {
			stack.push("memo:"+i);
			stack.push("memo:"+token);

			while (j > 0) {
				j--;
				stack.push(tokens[j]);
			}			
		}
		
		return child;				
		
	}
		
	
	
	public String newTestCase(int testCaseNum) {
		
		TreeNode root = getCoverageTree();
		String tc;
		
		if (root.isCovered()) {
			System.out.println("The test coverage tree is completely covered! No more test cases will be generated!");
			return null;
		}
		
		newHits();   /* reset the hits tracing for each new test case */
		emptyStack();
		resetFeature();
		resetAllFeatures();
//		resetParseTree();
		resetSemTree(getSymbolicGrammar().getMainVar());

		/* "semantics" is an indication to pop an item from the SemStack
		   it's a synchronization between (derivation) stack and SemStack */
		pushStack( "semantics" );  
		pushStack( getSymbolicGrammar().getMainVar() );
		
		pushSemStack( getSemTreeRoot() );
		
		featureCounter=1;
		outputFC.format("\nFeature Chain for test case "+testCaseNum+"....");
		tc = testCaseGeneration(root);
		outputFC.format("\n--------End of Feature Chain--------\n");
		printAllFeatures();
		
		return tc;
	}
	
	
	public String evaluate() {
		
		try {
			return evaluate( getSemTreeRoot() );
		}
		catch (Exception e) {
			return "exception";
		}
	}
	
		
	// evaluate the semantic node p, 
	// and write the evaluation result as p.element 
	// and return the evaluation result.
	private String evaluate(SemNode p) {
		
		if (p.getFirstChild() == null) 
			return p.getElement();
		
		p.setElement( evaluateFun(p.getFirstChild()) );
		return p.getElement();
	}

	
	private String evaluateFun( SemNode p ) {
		
		SemNode lambda = p.getFirstChild();
		
		// evaluate the lambda list and 
		// write the evaluation results into the list
		while (lambda != null) {
			evaluate(lambda);
			lambda = lambda.getNextSibling();
		}
		
		SemNode q = p.getNextSibling();
		
		return evaluateFunRec(q);
	}
	
	
		
	private String evaluateFunRec(SemNode q) {
	
		String functor = q.getElement();
		String args = null; 
		
		q = q.getNextSibling();
		while (q != null) {
			String str;
			if ( q.getElement() == null ) {
				// a nested semantic fun
				str = evaluateFunRec(q.getFirstChild());
			}
			else if ( isVar(q.getElement()) || isSymbolicTerminal(q.getElement()) ) 
				str = q.getFirstChild().getElement();  // retrieve value from the lambda list
			else
				str = q.getElement();
			
			if (args == null) 
				args = str;
			else
				args = args + "#" + str;
			
			q = q.getNextSibling();
		}
		
		return Funs.apply(functor, args.split("[#]"));
		
	}

	// Added by UNO
	/* This method will print the TreeNode details in the Traversal Chain for a particular
	 * test case. The traversal index simply enumerates the TreeNodes in this chain and has
	 * no relation to the index variable in the TreeNode structure.
	 */
	public void dumpTraversalChain(int i)
	{
		Iterator<TreeNode> itr = traversalChain.iterator();
		int traversalIndex = 1, isCoveredVal = 0;
		outputTC.format("\nTraversal Chain for test case "+i+"....");
		while(itr.hasNext())
		{
			TreeNode temp = itr.next();
			if(temp.isCovered())
				isCoveredVal = 1;
			else
				isCoveredVal = 0;
			outputTC.format("\nTraversal Index: %d Tree Node Information: (%f, %d, %d)", traversalIndex, temp.getRunningProbability(), temp.getIndex(), isCoveredVal);
            traversalIndex++;
		}
		outputTC.format("\n--------End of Traversal Chain--------\n");
	}
	
	// Added by UNO
	/* Clearing the traversal chain before the next test case */
	public void resetTraversalChain()
	{
		traversalChain.clear();
	}
	
	// Added by UNO
	/* Returns the length of the current traversal chain */
	public void lengthTraversalChain()
	{
		traversalChain.size();
	}
	
	// Added by UNO
	/* This method can be used to pop the nodes in the traversal chain
	 * if it is required by external application code.
	 */
	public void popTraversalChain()
	{
		traversalChain.pop();
	}	
	
	// Added by UNO
	/* This method will print the TreeNode details in the Traversal Chain for a particular
	 * test case. The traversal index simply enumerates the TreeNodes in this chain and has
	 * no relation to the index variable in the TreeNode structure.
	 */
	public void dumpExpressionChain(int i)
	{
		Iterator<String> itr = expressionChain.iterator();
		int expressionIndex = 1;
		outputEC.format("\nExpression Chain for test case "+i+"....");
		while(itr.hasNext())
		{
			outputEC.format("\nExpression Index: %d Expression: %s", expressionIndex, itr.next());
			expressionIndex++;
		}
		outputTC.format("\n--------End of Expression Chain--------\n");
	}
	
	// Added by UNO
	/* Clearing the exoression chain before the next test case */
	public void resetExpressionChain()
	{
		expressionChain.clear();
	}
	
	// Added by UNO
	/* Returns the length of the current expression chain */
	public void lengthExpressionChain()
	{
		expressionChain.size();
	}
	
	// Added by UNO
	/* This method can be used to pop the nodes in the expression chain
	 * if it is required by external application code.
	 */
	public void popExpressionChain()
	{
		expressionChain.pop();
	}	
	

	// Added by UNO
	/* Clearing the feature chain before the next test case */
	public void resetFeatureChain()
	{
		featureChain.clear();
	}
	
	// Added by UNO
	/* Returns the length of the current feature chain */
	public void lengthFeatureChain()
	{
		featureChain.size();
	}
	
	// Added by UNO
	/* This method can be used to pop the nodes in the feature chain
	 * if it is required by external application code.
	 */
	public void popFeatureChain()
	{
		featureChain.pop();
	}		
	

	private String testCaseGeneration(TreeNode p) {
		
		// Added by UNO
		traversalChain.add(p);
		
		if ( isEmptyStack() ) {
			// record the index at the leaf node of the path
			p.setIndex( incTestCaseIndex() );
			p.setCovered(true);
		}
		
		// if stack is not empty, test case generation continues ...
		String token = popStack();
		
		if (token.startsWith("memo:")) {
			// the end of derivation for the variable "token"
			token = token.substring(5);
			popStack();
			// the next line is related to parse tree
			//			appendParseTree(")");
	/*		
			int previous = stack.lastIndexOf("memo:"+token);

			if (previous > 0) {
				// the variable has been met before
				int pi = Integer.parseInt( stack.get(previous - 1).substring(5) ); 
				// remove the prefix "memo:"
				
//				ArrayList<Double> tokenHits = sg.getHits(token);

//				double w = 1.0;
				for (int j = previous + 1; j < stack.size(); j++) {
					if ( stack.get(j).matches("memo:[A-Z].*") )
						w /= 2;
				}
				
				// update the hits
//				tokenHits.set(pi, tokenHits.get(pi) / 2.0);
//				sg.setHitsMap(token, tokenHits);
			}
*/
			return testCaseGeneration(p);
		}
		
		String testcase;
			
//		p.setSymbols(token);
		if ( isVar(token) ) {
			
/*			if ( isEmptyFeature() )
				appendFeature(token);
	*/		
			
	// save space to comment the next line
	//		p.setSymbols( token + stack2Str() );
			TreeNode q = getDerivedNode(p, token);
//			q.setDerivedSymbols("");
			testcase = testCaseGeneration(q);
			if (q.isCovered()) {
				// if a child is recently completely covered
				if (p.checkCoveredViaChildren()) {
					// if all children are completely covered
					// in the other words, if p is completely covered
					p.setCovered(true);
					// no need to adjust the children's distributed probabilities
					// since they won't be visited again
				}
				else {
					// q is a new completely covered node
					double d = q.getRunningProbability();
					q.setRunningProbability(0.0);
					adjustChildPropDistribution(p, d);
				}
			}
			
			// Added by UNO
			expressionChain.add(testcase);
			
			return testcase;
		}
		else { // token is a regular terminal or symbolic terminal
			
	// to save space to comment the next line
	//		p.setDerivedSymbols( p.getDerivedSymbols() + token.replace("'", "") );
			
			if ( !isEmptyFeature() ) {
				printFeature();
				resetFeature();
			}
			
			String ins;
			if (isSymbolicTerminal(token)) {
				ins = getSymbolicGrammar().anInstanceFromSymbolic(token);

				if ( !stack.isEmpty() && stack.peek() == "semantics" ) {
					stack.pop();  // remove the indicator "semantics"
					SemNode sp = semStack.pop();
					sp.setElement(ins);
				}
			}
			else {
				ins = clearQuotesfromTerminal(token);
//				ins = token.replace("'", "");
			}
			
			
			if (isEmptyStack()) {
//				p.setSymbols(null);
				p.setCovered(true);   // leaf node
				p.setIndex( incTestCaseIndex() );
		
			/*  // the following lines for parse tree	
				String s = "";
				for (int i = 0; i < getStack().size() / 2; i++) {
					s += ")";
				}
				appendParseTree(s);
				
    */			
				// Added by UNO
				expressionChain.add(ins);
				
				return ins;
			}
			else {
/*				TreeNode child = p.getFirstChild();
				
				if (child == null) {
					child = new TreeNode();
					p.setFirstChild(child);
				}
				
				child.nodeReset(getHandler(), 1.0);
*/				
				testcase = ins + testCaseGeneration(p);
				
				// Added by UNO
				expressionChain.add(testcase);
				
				return testcase;				
			}
		}
			
	}
	
	
	private String clearQuotesfromTerminal(String s) {
		
		if (s.charAt(0) == '\'' && s.charAt(s.length()-1) == '\'') 
			return s.substring(1, s.length()-1);
		else
			return s;
	}
	
	
	

	public TreeNode newCoverageTree() {
		
		resetTestCaseIndex();
		if (getCoverageTree() != null) {
			incHandler();
//			getCoverageTree().setHandler( getHandler() );
			System.out.println(getCoverageTree());
			return getCoverageTree();
		}
		else if (getSymbolicGrammar() != null) {
			setHandler(0);
			newARoot();
			
			return getCoverageTree();
		}
		else {
			System.err.println("Coverage Tree Generation Error: no symblic grammar is set!");
			return null;
		}
	}
	
	
	private void newARoot() {
		root = new TreeNode();
//		root = new TreeNode(getHandler(), "start");
		// create a dummy "start" node, the root of a new coverage tree.
	}
	
	
	
	private void incHandler() {
		setHandler( getHandler() + 1 );
	}
	
	
	private void setHandler(int h) {
		handler = h;
	}
	
	private int getHandler() {
		return handler;
	}
	
	
	public TreeNode getCoverageTree() {
		System.out.println(root);
		return root;
	}
	
	private void adjustChildPropDistribution(TreeNode p, double d) {
		
		TreeNode child = p.getFirstChild();
		double newTotal = 1.0 - d;
		
		while (child != null) {
			child.setRunningProbability( child.getRunningProbability() / newTotal );
			child = child.getNextSibling();
		}
	}
	
	/*
	
	public void exportCoverageTree() {
		setOutputFile("coverageTree.dot");
		
		output.format("digraph G{\n");
		exportCoverageTree(root, 1);
		output.format("}\n");
		
		closeOutputFile();
	}
	

	private int exportCoverageTree(TreeNode p, int i) {
		
		// output the current node
		String symbol = p.getSymbols();
//		if (symbol != null) {
		if ( !p.isCovered() ) {
			if ( symbol != null )
				output.format("    n%d[label=\"%s\"];\n", i, symbol);
		}
		else if (symbol != null){
			output.format("    n%d[label=\"%s\",style=filled,color=\".7 .3 1.0\"];\n", i, symbol);
		}
		else {
			output.format("    n%d[peripheries=2,label=\"\",width=.1,height=.1,shape=box,style=filled,color=\".7 .3 1.0\"];\n", i);			
		}
//		}
//		else
//			output.format("    n%d[label=\"?\"];\n", i);
			
		int j = i + 1;
		
		TreeNode child = p.getFirstChild();
		while (child != null) {
			if ( child.isCovered() || child.getSymbols() != null ) {
				output.format("    n%d -> n%d [label=\"%s\"];\n", i, j, child.getDerivedSymbols());
				j = exportCoverageTree(child, j);
			}
			child = child.getNextSibling();
		}
		
		return j;
	}

	
	
	public void exportCoverageTreeWithProbability() {
		setOutputFile("coverageTree.dot");
		
		output.format("digraph G{\n");
		output.format("    node [shape = record];");
		exportCoverageTreeWithProbability(root, 1);
		output.format("}\n");
		
		closeOutputFile();
	}
	
	
	private int exportCoverageTreeWithProbability(TreeNode p, int i) {
		
		// output the current node
		String symbol = p.getSymbols();
//		if (symbol != null) {
		if ( !p.isCovered() ) {
			if ( symbol != null ) {
				double[] a = p.getChildrenProbability();
				String s = String.format("<f0> %.2f", a[0]);
				int k = 1;
				
				while (k < a.length) {
					s = String.format("%s |<f%d> %.2f", s, k, a[k]);
					k++;
				}
				
				output.format("    n%d[label=\"{%s | {%s}}\"];\n", i, symbol, s);
			}
		}
		else if (symbol != null){
			output.format("    n%d[label=\"%s\",style=filled,color=\".7 .3 1.0\"];\n", i, symbol);
		}
		else {
			output.format("    n%d[peripheries=2,label=\"\",width=.1,height=.1,shape=box,style=filled,color=\".7 .3 1.0\"];\n", i);			
		}
//		}
//		else
//			output.format("    n%d[label=\"?\"];\n", i);
			
		int j = i + 1;
		
		TreeNode child = p.getFirstChild();
		int k = 0;
		
		while (child != null) {
			if ( child.isCovered() || child.getSymbols() != null ) {
				output.format("    n%d:<f%d> -> n%d [label=\"%s\"];\n", i, k, j, child.getDerivedSymbols());
				j = exportCoverageTreeWithProbability(child, j);
			}
			child = child.getNextSibling();
			k++;
		}
		
		return j;
	}
	
	*/
	
	public boolean isSingletonFun(SemNode s) {
		
		if (s.getFirstChild() == null && s.getNextSibling() == null) 
			return true;
		else
			return false;
	}
	

	
	private boolean isVar(String v) {
//		System.out.println(v);	
		if (v == null)
			return false;
		return v.matches("[A-Z][a-zA-Z\\d]*"); 
	}

	private boolean isSymbolicTerminal(String t) {
		if (t == null)
			return false;
		if ( t.charAt(0) == '[' && t.charAt(t.length()-1) == ']' ) {
			return isVar(t.substring(1, t.length()-1));
		}
		else
			return false;
	}
	


	
}
